<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbName = "new_db";
$port = 3306;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbName, $port);

?>
