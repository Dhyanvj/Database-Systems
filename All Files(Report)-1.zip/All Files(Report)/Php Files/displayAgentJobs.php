<?php
include "dbConnection.php";
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "select * from AgentJobs";
$result = $conn->query($sql);

echo "<html><body>Agent Jobs<hr color='green'>";
echo "<table><tr><th>Agent Name</th><th>Number of Jobs</th></tr>";

if ($result->num_rows > 0) {

  while($row = $result->fetch_assoc()) {
    echo "<tr><td>" . $row['Agent_Name']."</td><td>". $row['Number_Of_Jobs']."</td></tr>";
  }
  } else {
    echo "0 results";
}
echo "</table></body></html>";
$conn->close();
?>
