package displayagenttable;


import java.sql.*;
public class DisplayAgentTable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Connection conn = null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/new_db?user=root");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT Agent_ID, Given_Name, Family_Name, Birth_Date, Hire_Date FROM Agent");
             while (rs.next()) {
                 System.out.print("\nAgent_ID:      " + rs.getString("Agent_ID"));
                 System.out.print(", Given_Name:    " + rs.getString("Given_Name"));
                 System.out.print(", Family_Name:   " + rs.getString("Family_Name"));
                 System.out.print(", Birth_Date:    " + rs.getString("Birth_Date"));
                 System.out.print(", Hire_Date:     " + rs.getString("Hire_Date"));
             }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
}
