-- Q 1.2  Design Tables

CREATE TABLE Agent 
    (
    Agent_ID NUMBER(20) NOT NULL
    CONSTRAINT agent_agentid_pk PRIMARY KEY,
    Given_Name VARCHAR2(30),
    Family_Name VARCHAR2(30),
    Birth_Date DATE,
    Hire_Date DATE
    );
    
DESC Agent;
    
CREATE TABLE Band
    (
    Band_Name VARCHAR2(30) NOT NULL
    CONSTRAINT band_bandname_pk PRIMARY KEY,
    DESCRIPTION VARCHAR2(300),
    Agent_ID NUMBER(20) NOT NULL,
    CONSTRAINT band_agentid_fk FOREIGN KEY
    (Agent_ID) REFERENCES Agent(Agent_ID)
    );
    
DESC Band;
    
CREATE TABLE Member
    (
    Member_ID NUMBER(20) NOT NULL
    CONSTRAINT staff_staffid_pk PRIMARY KEY,
    Given_Name VARCHAR(30),
    Family_Name VARCHAR(30),
    Birth_Date DATE,
    Hire_Date DATE,
    Job_Type VARCHAR(60),
    Band_Name VARCHAR2(30) NOT NULL,
    CONSTRAINT staff_bandname_fk FOREIGN KEY
    (Band_Name) REFERENCES Band(Band_Name)
    );
    
DESC Member;

CREATE TABLE Stage
    (
    Stage_ID NUMBER(20) NOT NULL
    CONSTRAINT stage_stageid_pk PRIMARY KEY,
    Stage_Name VARCHAR(60),
    Max_Capacity NUMBER(25)
    );
    
DESC Stage;
    
CREATE TABLE Performance
    (
    Performance_ID NUMBER(20) NOT NULL
    CONSTRAINT perform_performid_pk PRIMARY KEY,
    Stage_ID NUMBER(20) NOT NULL,
    Act_Date DATE,
    Start_Time TIMESTAMP,
    Finish_Time TIMESTAMP,
    Band_Name VARCHAR2(30) NOT NULL,
    CONSTRAINT perform_bandname_fk FOREIGN KEY
    (Band_Name) REFERENCES Band(Band_Name),
    CONSTRAINT perform_stageid_fk FOREIGN KEY
    (Stage_ID) REFERENCES Stage(Stage_ID)
    );
    
DESC Performance;



--DROP TABLE Agent CASCADE CONSTRAINTS;
--DROP TABLE Band CASCADE CONSTRAINTS;
--DROP TABLE Member CASCADE CONSTRAINTS;
--DROP TABLE Stage CASCADE CONSTRAINTS;
--DROP TABLE Performance CASCADE CONSTRAINTS;
    
    
    
