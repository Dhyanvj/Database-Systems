-- Q 1.5 SQL Tigger

-- Create Table that counts number of times data is deleted

CREATE TABLE tblCountDelete
    (
    countDelete INT
    );

INSERT INTO tblCountDelete VALUES(0);
-- Before Trigger
SELECT * FROM tblCountDelete;





-- SQL Tigger
CREATE TRIGGER Deleted
AFTER DELETE ON Agent
FOR EACH ROW
BEGIN
 UPDATE tblCountDelete set countDelete = countDelete + 1;
END;





-- Dummy Data 1
INSERT INTO Agent (Agent_ID, Given_Name, Family_Name, Birth_Date, Hire_Date)
VALUES ( '12345', 'Dummy1', 'Data1', TO_DATE('10/01/1995', 'DD/MM/YYYY'), TO_DATE('15/11/2015', 'DD/MM/YYYY'));
-- Dummy Data 2
INSERT INTO Agent (Agent_ID, Given_Name, Family_Name, Birth_Date, Hire_Date)
VALUES ( '12346', 'Dummy2', 'Data2', TO_DATE('20/05/1990', 'DD/MM/YYYY'), TO_DATE('25/05/2016', 'DD/MM/YYYY'));
-- Dummy Data 3
INSERT INTO Agent (Agent_ID, Given_Name, Family_Name, Birth_Date, Hire_Date)
VALUES ( '12347', 'Dummy3', 'Data3', TO_DATE('10/10/1989', 'DD/MM/YYYY'), TO_DATE('13/10/2017', 'DD/MM/YYYY'));

--Delete Data 1
DELETE FROM Agent WHERE Agent_ID = 12345;
--Delete Data 2
DELETE FROM Agent WHERE Agent_ID = 12346;
--Delete Data 3
DELETE FROM Agent WHERE Agent_ID = 12347;
--After Trigger
SELECT * FROM tblCountDelete;






--DROP TABLE tblCountDelete CASCADE CONSTRAINTS;
--DROP TRIGGER Deleted;
 

