-- Q 1.3 Insert Data

-- 2 Agents

-- Agent 1
INSERT INTO Agent (Agent_ID, Given_Name, Family_Name, Birth_Date, Hire_Date)
VALUES ( '2468101214', 'Rowan', 'Atkinson', TO_DATE('06/01/1990', 'DD/MM/YYYY'), TO_DATE('12/12/2020', 'DD/MM/YYYY'));
-- Agent 2
INSERT INTO Agent (Agent_ID, Given_Name, Family_Name, Birth_Date, Hire_Date)
VALUES ( '3691215182', 'Charlie', 'Chaplin', TO_DATE('16/04/1985', 'DD/MM/YYYY'), TO_DATE('25/06/2018', 'DD/MM/YYYY'));

-- 5 Bands

-- Band 1
INSERT INTO Band (Band_Name, Description, Agent_ID)
VALUES ( 'Queen', 'They are the kings of arena rock and pop rock', '2468101214');
-- Band 2
INSERT INTO Band (Band_Name, Description, Agent_ID)
VALUES ( 'Rush', 'Rush is progressive rock god', '2468101214');
-- Band 3
INSERT INTO Band (Band_Name, Description, Agent_ID)
VALUES ( 'Yes', 'Yes played music in the blues-rock and folk-rock genres', '2468101214');
-- Band 4
INSERT INTO Band (Band_Name, Description, Agent_ID)
VALUES ( 'Maroon', 'American pop rock band from Los Angeles', '3691215182');
-- Band 5
INSERT INTO Band (Band_Name, Description, Agent_ID)
VALUES ( 'BTS', 'Kpop boy band from BigHit Entertainment', '3691215182');

-- 20 Musicians

-- Band 1 = 4 Musicians
INSERT INTO Member VALUES ( '21005078', 'James', 'Adler', TO_DATE('07/04/1996', 'DD/MM/YYYY'), TO_DATE('02/12/2016', 'DD/MM/YYYY'), 'Musician', 'Queen');
INSERT INTO Member VALUES ( '21005079', 'Robert', 'Anderson', TO_DATE('03/07/1988', 'DD/MM/YYYY'), TO_DATE('07/11/2021', 'DD/MM/YYYY'), 'Composer', 'Queen');
INSERT INTO Member VALUES ( '21005080', 'John', 'Beckett', TO_DATE('09/05/1990', 'DD/MM/YYYY'), TO_DATE('12/09/2019', 'DD/MM/YYYY'), 'Instrument Technician', 'Queen');
INSERT INTO Member VALUES ( '21005081', 'Michael', 'Carson', TO_DATE('10/09/1994', 'DD/MM/YYYY'), TO_DATE('18/06/2017', 'DD/MM/YYYY'), 'Bassist', 'Queen');
-- Band 2 = 4 Musicians
INSERT INTO Member VALUES ( '21006112', 'David', 'Brady', TO_DATE('12/11/2002', 'DD/MM/YYYY'), TO_DATE('19/01/2018', 'DD/MM/YYYY'), 'Musician', 'Rush');
INSERT INTO Member VALUES ( '21006113', 'William', 'Cooper', TO_DATE('14/02/1993', 'DD/MM/YYYY'), TO_DATE('09/09/2020', 'DD/MM/YYYY'), 'DJ', 'Rush');
INSERT INTO Member VALUES ( '21006114', 'Richard', 'Davis', TO_DATE('18/01/2001', 'DD/MM/YYYY'), TO_DATE('21/08/2019', 'DD/MM/YYYY'), 'Drummer', 'Rush');
INSERT INTO Member VALUES ( '21006115', 'Joseph', 'Dixon', TO_DATE('19/12/2000', 'DD/MM/YYYY'), TO_DATE('05/07/2021', 'DD/MM/YYYY'), 'Guitarist', 'Rush');
-- Band 3 = 4 Musicians
INSERT INTO Member VALUES ( '21007232', 'Thomas', 'Lennox', TO_DATE('22/11/1995', 'DD/MM/YYYY'), TO_DATE('22/02/2014', 'DD/MM/YYYY'), 'Musician', 'Yes');
INSERT INTO Member VALUES ( '21007233', 'Daniel', 'Lincoln', TO_DATE('13/08/1995', 'DD/MM/YYYY'), TO_DATE('24/12/2016', 'DD/MM/YYYY'), 'Keyboardist', 'Yes');
INSERT INTO Member VALUES ( '21007234', 'Mary', 'Mason', TO_DATE('17/10/1997', 'DD/MM/YYYY'), TO_DATE('16/11/2016', 'DD/MM/YYYY'), 'Bassist', 'Yes');
INSERT INTO Member VALUES ( '21007235', 'Jennifer', 'Wiley', TO_DATE('27/02/1987', 'DD/MM/YYYY'), TO_DATE('19/04/2018', 'DD/MM/YYYY'), 'Drummer', 'Yes');
-- Band 4 = 4 Musicians
INSERT INTO Member VALUES ( '21008356', 'Lisa', 'Walker', TO_DATE('25/02/2000', 'DD/MM/YYYY'), TO_DATE('09/06/2018', 'DD/MM/YYYY'), 'Musician', 'Maroon');
INSERT INTO Member VALUES ( '21008357', 'Steven', 'Wilson', TO_DATE('14/04/1994', 'DD/MM/YYYY'), TO_DATE('17/08/2019', 'DD/MM/YYYY'), 'Sound Technician', 'Maroon');
INSERT INTO Member VALUES ( '21008358', 'Paul', 'Parker', TO_DATE('18/11/1998', 'DD/MM/YYYY'), TO_DATE('15/10/2020', 'DD/MM/YYYY'), 'Event Manager', 'Maroon');
INSERT INTO Member VALUES ( '21008359', 'Ronald', 'Miler', TO_DATE('08/04/1999', 'DD/MM/YYYY'), TO_DATE('11/03/2020', 'DD/MM/YYYY'), 'Guitarist', 'Maroon');
-- Band 5 = 4 Musicians
INSERT INTO Member VALUES ( '21009462', 'Sharon', 'Nash', TO_DATE('22/05/2002', 'DD/MM/YYYY'), TO_DATE('23/01/2017', 'DD/MM/YYYY'), 'Musician', 'BTS');
INSERT INTO Member VALUES ( '21009463', 'Jacob', 'Smith', TO_DATE('26/08/1994', 'DD/MM/YYYY'), TO_DATE('16/02/2018', 'DD/MM/YYYY'), 'Singer', 'BTS');
INSERT INTO Member VALUES ( '21009465', 'Stephen', 'Stone', TO_DATE('08/09/1996', 'DD/MM/YYYY'), TO_DATE('24/04/2020', 'DD/MM/YYYY'), 'Bassist', 'BTS');
INSERT INTO Member VALUES ( '21009466', 'Alexander', 'Thompson', TO_DATE('06/03/1993', 'DD/MM/YYYY'), TO_DATE('26/06/2019', 'DD/MM/YYYY'), 'Composer', 'BTS');

