-- Q 1.4 SQL VIEWS

CREATE VIEW AgentJobs
AS
SELECT Agent.Given_Name AS "Agent_Name",
COUNT(Member.Job_Type) AS "Number_Of_Jobs"
FROM Agent, Band, Member
WHERE Agent.Agent_ID = Band.Agent_ID
AND Band.Band_Name = Member.Band_Name
GROUP BY Agent.Given_Name
WITH READ ONLY;



GRANT SELECT ON AgentJobs to dp15aad;


SELECT * FROM AgentJobs;







--REVOKE select on AgentJobs from dp15aad;
--DROP VIEW AgentJobs;